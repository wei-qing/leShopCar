<template>
  <div class="cart">
    <div class="title">购物车</div>
    <div class="cart-ct">
      <div >
        <van-swipe-cell v-for="(item,index) in cartList" :key="index">
          <van-card
            num="2"
            :price="item.price"
            desc="描述信息"
            :title="item.title"
            class="goods-card"
            :thumb="item.image"
          />
          <template #right>
            <van-button square text="删除" type="danger" class="delete-button" />
          </template>
        </van-swipe-cell>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      cartList: [],
    };
  },
  mounted() {
    this.$getlist.getCartss().then((res) => {
      this.cartList = res.data.data;
      var cartLists=this.cartList
     
        cartLists.pop()
    
      this.cartList=cartLists
      console.log(this.cartList);
    });
  },
};
</script>

<style>
.cart {
  width: 100%;
  height: 1200px;
}
.title {
  width: 100%;
  height: 64px;
  font-size: 25px;
  display: inline-flex;
  justify-content: center;
  align-content: center;
}
.cart-ct {
  width: 100%;
  height: 1000px;
  background: skyblue;
}
.goods-card {
  margin: 0;
}

.delete-button {
  height: 100%;
}
</style>