export const GET ="get"
export const POST ="post"

export const path={
    // 首页数据接口
    homeList:"Home/getHomeREC",
    // 商品分类列表数据接口
    categorylist:"Home/getHomeShowGoods",
    //详情数据
    detailes:"Goods/GetGoodsInfo",
    // 手机号
    phone:"Verify/GetPhone",
    // 用户名判断
    userName:"Verify/LoginName",
    // 验证码
    SMS:"SMSCode/GetCode",
    // 添加登录信息
    addUser:"LoginPage/AddLogin",
    // 商品一级分类
    oneClassify:"Goods/getCatsTree",
    // 商品二级分类
    twoClassify:"Goods/getCadGoods",
    // 搜索接口
    search:"Goods/getGoods",
    // 搜索第二接口
    searchtwo:"Goods/getSearchHot",
    // 添加购物车
    addCart:"Cart/addCart",
    // 获取购物车信息
    getCart:"Cart/getCart",
    // 获取购物车数量
    cartCount:"Cart/getCartLength"


}