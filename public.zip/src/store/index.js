import Vue from 'vue'
import Vuex from 'vuex'
// import getlist from '../network/index'
import createisitate from "vuex-persistedstate"
Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    token:{},
    cartList:[],
  },
  mutations: {
    addLogin(state,item){
      state.token=item
    },
    addCarts(state,item){
      state.cartList=item
    }
  },
  actions: {
    addLogin(context,item){
      context.commit("addLogin",item)
    },
    addCarts(context,item){
      
      
    
       context.commit('addCarts',item)
        console.log(item);
        console.log(111)
      
    }
  },
  modules: {
  },
  plugins:[createisitate({
        storage:window.localStorage
      })]
})
